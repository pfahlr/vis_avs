//////////////////////////////////////////////////////////////////////////////// 
/// Plainamp, Open source Winamp core
/// 
/// Copyright � 2005  Sebastian Pipping <webmaster@hartwork.org>
/// 
/// -->  http://www.hartwork.org
/// 
/// This source code is released under the GNU General Public License (GPL).
/// See GPL.txt for details. Any non-GPL usage is strictly forbidden.
////////////////////////////////////////////////////////////////////////////////


#ifndef PA_GLOBAL_TEST_H
#define PA_GLOBAL_TEST_H



#include <windows.h>
#include <tchar.h>



#endif // PA_GLOBAL_TEST_H
